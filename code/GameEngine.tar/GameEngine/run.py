from includes.gameEngine import GameEngine


if __name__ == '__main__':
   
   #loadFile = raw_input("File to use: ")
   
   g = GameEngine("maps/surveyMap000.json", (640,480))
   g.run()
   